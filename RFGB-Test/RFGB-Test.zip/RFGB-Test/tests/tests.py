import unittest

class MyTest(unittest.TestCase):

    def test_unit_testing(self):
        self.assertTrue(True)
        self.assertEqual(1, 1)

if __name__ == '__main__':
    unittest.main()
